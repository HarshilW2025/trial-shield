# Trial Shield: feasibility proof

A working proof that the Protected card can stop subscription traps:

* `extension/`: a real Chrome extension. On a checkout page it reads the fine print, suggests the Protected card and fills it with a one-time CVV once you approve in the banking app. It works on plain checkout forms and inside payment providers' card frames.
* `bank/`: the bank side. It makes the one-time CVV (RFC 4226), decides each payment the way an issuer would, and shows the banking app page where you approve. It also runs two made-up shops with back offices that send the later charges.
* `FEASIBILITY.md`: the evidence table, with sources.
* `screenshots/`: the end-to-end run in Chrome.

Python 3.9 or later. No packages to install. All card numbers are made up and can't be charged anywhere.

## Run it (2 minutes)

1. Start the bank and the shops:
   ```
   cd bank
   python3 server.py          # add --lan to open the banking app on your phone (same Wi-Fi)
   ```
2. Load the extension in Chrome: go to `chrome://extensions`, turn on **Developer mode**, click **Load unpacked**, and choose the `extension` folder.
3. Open the banking app at http://127.0.0.1:8790/app, side by side with the shop, or on your phone with `--lan`.

## Demo for the mentors

1. Open http://localhost:8801. The extension panel opens with the catch in red: $1 today, then about $114.90 a month.
2. Keep **Protected card**, click **Fill card details**, then **Approve with Face ID** in the banking app. The card number and a one-time CVV appear in the form.
3. Click **Pay $1.00**: approved. Click it again: **declined N7, one-time CVV already used**.
4. Open http://localhost:8801/office, the shop's back office:
   * **Charge the subscription**: declined `05`, and an approval request appears in the banking app. Each result shows the exact message sent to the bank and its reply.
   * **Dishonest: no labels**: still declined.
   * **Attacker: reuse the card details**: declined `N7`.
5. Approve the $89.95 in the banking app, then charge again: approved, once. Charge again: it asks again.
6. Open http://localhost:8802. The card fields there belong to a different origin, like Stripe's, and the extension still fills them.
7. For contrast, choose **Everyday Debit** in the panel to see the warning about what would go through.

## Tests

```
cd bank
python3 tests.py
```
This runs 16 tests, including the RFC 4226 reference values and every trap, plus a 100,000 attack brute-force simulation.
